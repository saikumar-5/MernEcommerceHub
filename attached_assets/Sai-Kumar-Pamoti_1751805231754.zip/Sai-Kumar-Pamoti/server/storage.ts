import { users, contacts, comments, analytics, type User, type InsertUser, type Contact, type InsertContact, type Comment, type InsertComment, type Analytics } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  getUnreadContacts(): Promise<Contact[]>;
  markContactAsRead(id: number): Promise<void>;
  
  // Comment methods
  createComment(comment: InsertComment): Promise<Comment>;
  getApprovedComments(): Promise<Comment[]>;
  getPendingComments(): Promise<Comment[]>;
  approveComment(id: number): Promise<void>;
  rejectComment(id: number): Promise<void>;
  likeComment(id: number): Promise<void>;
  
  // Analytics methods
  recordPageView(): Promise<void>;
  getAnalytics(): Promise<Analytics | undefined>;
  updateAnalytics(totalViews: number, uniqueVisitors: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contacts: Map<number, Contact>;
  private comments: Map<number, Comment>;
  private analytics: Analytics | null;
  private currentUserId: number;
  private currentContactId: number;
  private currentCommentId: number;

  constructor() {
    this.users = new Map();
    this.contacts = new Map();
    this.comments = new Map();
    this.analytics = {
      id: 1,
      date: new Date(),
      totalViews: 0,
      uniqueVisitors: 0,
      pageViews: 0,
    };
    this.currentUserId = 1;
    this.currentContactId = 1;
    this.currentCommentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const contact: Contact = {
      ...insertContact,
      id,
      createdAt: new Date(),
      isRead: false,
      subject: insertContact.subject || null,
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getUnreadContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values())
      .filter(contact => !contact.isRead)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async markContactAsRead(id: number): Promise<void> {
    const contact = this.contacts.get(id);
    if (contact) {
      this.contacts.set(id, { ...contact, isRead: true });
    }
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: new Date(),
      isApproved: false,
      likes: 0,
      email: insertComment.email || null,
      profession: insertComment.profession || null,
    };
    this.comments.set(id, comment);
    return comment;
  }

  async getApprovedComments(): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.isApproved)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getPendingComments(): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => !comment.isApproved)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async approveComment(id: number): Promise<void> {
    const comment = this.comments.get(id);
    if (comment) {
      this.comments.set(id, { ...comment, isApproved: true });
    }
  }

  async rejectComment(id: number): Promise<void> {
    this.comments.delete(id);
  }

  async likeComment(id: number): Promise<void> {
    const comment = this.comments.get(id);
    if (comment) {
      this.comments.set(id, { ...comment, likes: comment.likes + 1 });
    }
  }

  async recordPageView(): Promise<void> {
    if (this.analytics) {
      this.analytics.pageViews += 1;
      this.analytics.totalViews += 1;
    }
  }

  async getAnalytics(): Promise<Analytics | undefined> {
    return this.analytics || undefined;
  }

  async updateAnalytics(totalViews: number, uniqueVisitors: number): Promise<void> {
    if (this.analytics) {
      this.analytics.totalViews = totalViews;
      this.analytics.uniqueVisitors = uniqueVisitors;
    }
  }
}

// DatabaseStorage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const [contact] = await db
      .insert(contacts)
      .values({
        ...insertContact,
        subject: insertContact.subject || null,
      })
      .returning();
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return await db.select().from(contacts).orderBy(desc(contacts.createdAt));
  }

  async getUnreadContacts(): Promise<Contact[]> {
    return await db.select().from(contacts)
      .where(eq(contacts.isRead, false))
      .orderBy(desc(contacts.createdAt));
  }

  async markContactAsRead(id: number): Promise<void> {
    await db.update(contacts)
      .set({ isRead: true })
      .where(eq(contacts.id, id));
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values({
        ...insertComment,
        email: insertComment.email || null,
        profession: insertComment.profession || null,
      })
      .returning();
    return comment;
  }

  async getApprovedComments(): Promise<Comment[]> {
    return await db.select().from(comments)
      .where(eq(comments.isApproved, true))
      .orderBy(desc(comments.createdAt));
  }

  async getPendingComments(): Promise<Comment[]> {
    return await db.select().from(comments)
      .where(eq(comments.isApproved, false))
      .orderBy(desc(comments.createdAt));
  }

  async approveComment(id: number): Promise<void> {
    await db.update(comments)
      .set({ isApproved: true })
      .where(eq(comments.id, id));
  }

  async rejectComment(id: number): Promise<void> {
    await db.delete(comments).where(eq(comments.id, id));
  }

  async likeComment(id: number): Promise<void> {
    await db.update(comments)
      .set({ likes: sql`${comments.likes} + 1` })
      .where(eq(comments.id, id));
  }

  async recordPageView(): Promise<void> {
    const [existingAnalytics] = await db.select().from(analytics).limit(1);
    
    if (existingAnalytics) {
      await db.update(analytics)
        .set({ 
          totalViews: existingAnalytics.totalViews + 1,
          pageViews: existingAnalytics.pageViews + 1 
        })
        .where(eq(analytics.id, existingAnalytics.id));
    } else {
      await db.insert(analytics).values({
        totalViews: 1,
        uniqueVisitors: 1,
        pageViews: 1,
      });
    }
  }

  async getAnalytics(): Promise<Analytics | undefined> {
    const [analyticsData] = await db.select().from(analytics).limit(1);
    return analyticsData || undefined;
  }

  async updateAnalytics(totalViews: number, uniqueVisitors: number): Promise<void> {
    const [existingAnalytics] = await db.select().from(analytics).limit(1);
    
    if (existingAnalytics) {
      await db.update(analytics)
        .set({ totalViews, uniqueVisitors })
        .where(eq(analytics.id, existingAnalytics.id));
    } else {
      await db.insert(analytics).values({
        totalViews,
        uniqueVisitors,
        pageViews: totalViews,
      });
    }
  }
}

export const storage = new DatabaseStorage();
