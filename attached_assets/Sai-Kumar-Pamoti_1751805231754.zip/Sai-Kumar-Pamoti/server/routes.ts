import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema, insertCommentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Analytics route
  app.get("/api/analytics", async (req, res) => {
    try {
      await storage.recordPageView();
      const analytics = await storage.getAnalytics();
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ message: "Failed to get analytics" });
    }
  });

  // Contact routes
  app.post("/api/contacts", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(validatedData);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create contact" });
      }
    }
  });

  app.get("/api/contacts", async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get contacts" });
    }
  });

  app.get("/api/contacts/unread", async (req, res) => {
    try {
      const contacts = await storage.getUnreadContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to get unread contacts" });
    }
  });

  app.patch("/api/contacts/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markContactAsRead(id);
      res.json({ message: "Contact marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark contact as read" });
    }
  });

  // Comment routes
  app.post("/api/comments", async (req, res) => {
    try {
      const validatedData = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create comment" });
      }
    }
  });

  app.get("/api/comments", async (req, res) => {
    try {
      const comments = await storage.getApprovedComments();
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get comments" });
    }
  });

  app.get("/api/comments/pending", async (req, res) => {
    try {
      const comments = await storage.getPendingComments();
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get pending comments" });
    }
  });

  app.patch("/api/comments/:id/approve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.approveComment(id);
      res.json({ message: "Comment approved" });
    } catch (error) {
      res.status(500).json({ message: "Failed to approve comment" });
    }
  });

  app.delete("/api/comments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.rejectComment(id);
      res.json({ message: "Comment rejected" });
    } catch (error) {
      res.status(500).json({ message: "Failed to reject comment" });
    }
  });

  app.patch("/api/comments/:id/like", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.likeComment(id);
      res.json({ message: "Comment liked" });
    } catch (error) {
      res.status(500).json({ message: "Failed to like comment" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
