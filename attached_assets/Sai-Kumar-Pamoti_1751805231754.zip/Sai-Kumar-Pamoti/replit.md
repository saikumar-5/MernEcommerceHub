# Replit.md

## Overview

This is a full-stack portfolio website application built with React (TypeScript) on the frontend and Express.js on the backend. The application showcases a cybersecurity enthusiast and full-stack developer's portfolio with interactive features including contact forms, comment systems, and analytics dashboard. The application uses a modern tech stack with shadcn/ui components for the UI, Drizzle ORM for database management, and is designed for deployment on Replit.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful API architecture
- **Data Layer**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: Built-in session handling for analytics
- **Middleware**: Custom logging and error handling middleware

### Database Schema
The application uses PostgreSQL with the following main entities:
- **Users**: Authentication and user management
- **Contacts**: Contact form submissions with read/unread status
- **Comments**: User comments with approval workflow and like system
- **Analytics**: Page view tracking and visitor statistics

## Key Components

### Frontend Components
- **Navigation**: Fixed header with smooth scrolling to sections
- **Hero Section**: Animated typing effect and particle background
- **About Section**: Personal information with education details
- **Projects Section**: Showcase of key projects with categorization
- **Experience Section**: Timeline-based work experience display
- **Skills Section**: Animated skill bars and technology listings
- **Contact Section**: Form validation with Zod schema
- **Comments Section**: Interactive comment system with real-time updates
- **Dashboard Section**: Analytics and admin functionality

### Backend API Endpoints
- **Analytics**: `GET /api/analytics` - Page view tracking and statistics
- **Contacts**: `POST /api/contacts`, `GET /api/contacts`, `GET /api/contacts/unread`
- **Comments**: `POST /api/comments`, `GET /api/comments`, comment moderation endpoints

### Storage Layer
- **Interface-based Design**: IStorage interface for flexible storage implementations
- **Memory Storage**: In-memory storage for development/testing
- **Database Integration**: Drizzle ORM with PostgreSQL for production

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **API Processing**: Express.js routes handle requests with validation
3. **Data Layer**: Storage interface abstracts database operations
4. **Response**: JSON responses with proper error handling
5. **State Updates**: TanStack Query manages cache invalidation and updates

### Form Processing
- Contact and comment forms use react-hook-form with Zod validation
- Server-side validation mirrors client-side schemas
- Success/error states handled through toast notifications

## External Dependencies

### Frontend Dependencies
- **UI Libraries**: Radix UI primitives, Lucide React icons
- **Form Management**: React Hook Form with Zod resolvers
- **Animation**: Custom CSS animations and transitions
- **Date Handling**: date-fns for date manipulation

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: Drizzle ORM with Zod integration
- **Session**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution, esbuild for production builds

### Development Tools
- **Build System**: Vite with React plugin and runtime error overlay
- **Database Migrations**: Drizzle Kit for schema management
- **Code Quality**: TypeScript strict mode, ESLint configuration
- **Styling**: PostCSS with Tailwind CSS and Autoprefixer

## Deployment Strategy

### Development Environment
- Vite dev server with HMR (Hot Module Replacement)
- Express server with custom middleware for API and static file serving
- Database schema pushing with Drizzle Kit
- Real-time error overlay for development debugging

### Production Build
- Frontend: Vite builds optimized React bundle
- Backend: esbuild bundles Express server with external dependencies
- Static files served from Express in production mode
- Environment-based configuration for database connections

### Replit Integration
- Custom Vite plugins for Replit cartographer integration
- Development banner injection for external access
- File system restrictions and security configurations
- Environment variable management for database connections

## Changelog

```
Changelog:
- July 06, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```