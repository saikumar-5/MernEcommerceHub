import { useEffect } from "react";
import { Navigation } from "@/components/navigation";
import { CustomCursor } from "@/components/custom-cursor";
import { HeroSection } from "@/components/hero-section";
import { AboutSection } from "@/components/about-section";
import { ProjectsSection } from "@/components/projects-section";
import { ExperienceSection } from "@/components/experience-section";
import { SkillsSection } from "@/components/skills-section";
import { ContactSection } from "@/components/contact-section";
import { CommentsSection } from "@/components/comments-section";
import { DashboardSection } from "@/components/dashboard-section";
import { animateOnScroll, animateSkillBars, smoothScrollToSection } from "@/lib/animations";
import { useRecordPageView } from "@/hooks/use-analytics";
import { Github, Linkedin, Code } from "lucide-react";

export default function Home() {
  const recordPageView = useRecordPageView();
  const isAdmin = window.location.search.includes('admin=true');

  useEffect(() => {
    // Record page view
    recordPageView.mutate();

    // Set up animations
    const scrollObserver = animateOnScroll();
    const skillObserver = animateSkillBars();

    // Set up smooth scrolling for navigation links
    const handleSmoothScroll = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.href && target.href.includes('#')) {
        e.preventDefault();
        const href = target.getAttribute('href');
        if (href) {
          smoothScrollToSection(href);
        }
      }
    };

    document.addEventListener('click', handleSmoothScroll);

    return () => {
      scrollObserver.disconnect();
      skillObserver.disconnect();
      document.removeEventListener('click', handleSmoothScroll);
    };
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <CustomCursor />
      <Navigation />
      
      <main>
        <HeroSection />
        <AboutSection />
        <ExperienceSection />
        <ProjectsSection />
        <SkillsSection />
        <ContactSection />
        <CommentsSection />
        {isAdmin && <DashboardSection />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-bold text-primary font-mono mb-4 md:mb-0">
              Sai Kumar
            </div>
            
            <div className="flex space-x-6">
              <a 
                href="https://linkedin.com/in/sai-kumar-pamoti-b6711829" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-slate-400 hover:text-primary transition-colors duration-300"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="https://github.com/saikumar-5" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-slate-400 hover:text-primary transition-colors duration-300"
              >
                <Github size={20} />
              </a>
              <a 
                href="#" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-slate-400 hover:text-primary transition-colors duration-300"
              >
                <Code size={20} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
