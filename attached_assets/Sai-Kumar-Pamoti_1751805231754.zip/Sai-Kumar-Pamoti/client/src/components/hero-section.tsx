import { useEffect, useState } from "react";
import { Github, Linkedin, Code, ChevronDown } from "lucide-react";

export function HeroSection() {
  const [typedText, setTypedText] = useState("");
  const [showCursor, setShowCursor] = useState(true);
  const fullText = "Sai Kumar Pamoti";

  useEffect(() => {
    let index = 0;
    const typeWriter = () => {
      if (index < fullText.length) {
        setTypedText(fullText.slice(0, index + 1));
        index++;
        setTimeout(typeWriter, 120);
      } else {
        setTimeout(() => {
          index = 0;
          setTypedText("");
          typeWriter();
        }, 3000);
      }
    };
    typeWriter();

    // Cursor blinking effect
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 530);

    return () => clearInterval(cursorInterval);
  }, []);

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated background particles */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-primary rounded-full animate-float"></div>
        <div className="absolute top-3/4 right-1/4 w-1 h-1 bg-primary/70 rounded-full animate-float" style={{ animationDelay: "2s" }}></div>
        <div className="absolute top-1/2 left-3/4 w-1.5 h-1.5 bg-primary/80 rounded-full animate-float" style={{ animationDelay: "4s" }}></div>
      </div>
      
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="mb-8 animate-slide-up">
          <h1 className="text-5xl md:text-7xl font-bold mb-4">
            <span className="text-primary font-mono">&gt; </span>
            <span className="font-mono">{typedText}</span>
            <span className={`text-primary font-mono ${showCursor ? 'opacity-100' : 'opacity-0'} transition-opacity duration-100`}>_</span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 mb-8">Cybersecurity & Technology Enthusiast</p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12 animate-fade-in">
          <span className="px-4 py-2 bg-slate-800 rounded-full text-sm border border-primary/30">
            <i className="fas fa-code text-primary mr-2"></i>Full Stack Development
          </span>
          <span className="px-4 py-2 bg-slate-800 rounded-full text-sm border border-primary/30">
            <i className="fas fa-shield-alt text-primary mr-2"></i>Security
          </span>
          <span className="px-4 py-2 bg-slate-800 rounded-full text-sm border border-primary/30">
            <i className="fas fa-brain text-primary mr-2"></i>Problem Solving
          </span>
          <span className="px-4 py-2 bg-slate-800 rounded-full text-sm border border-primary/30">
            <i className="fas fa-flask text-primary mr-2"></i>Research
          </span>
        </div>
        
        <div className="flex justify-center space-x-6 mb-12 animate-fade-in">
          <a href="https://linkedin.com/in/sai-kumar-pamoti-b6711829" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-primary transition-colors duration-300 hover:scale-110 transform">
            <Linkedin />
          </a>
          <a href="https://github.com/saikumar-5" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-primary transition-colors duration-300 hover:scale-110 transform">
            <Github />
          </a>
          <a href="#" target="_blank" rel="noopener noreferrer" className="text-3xl hover:text-primary transition-colors duration-300 hover:scale-110 transform">
            <Code />
          </a>
        </div>
        
        <div className="animate-fade-in">
          <button 
            onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-block bg-primary hover:bg-primary/80 text-background font-semibold px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105 animate-glow"
          >
            View My Work
          </button>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-primary text-2xl" />
      </div>
    </section>
  );
}
