import { ExternalLink, Github } from "lucide-react";

export function ProjectsSection() {
  const projects = [
    {
      title: "PHISHX",
      subtitle: "Phishing Detection Extension",
      description: "Developed a browser extension that extracts and analyzes URLs using a Flask-based backend and XGBoost ML model (97% accuracy) to detect phishing websites with real-time predictions.",
      tags: ["Python", "Flask", "XGBoost", "ML"],
      category: "Security",
      categoryColor: "bg-red-500/20 text-red-400",
      accuracy: "97%",
      githubUrl: "#",
      liveUrl: "#"
    },
    {
      title: "AGRIMART",
      subtitle: "Online Marketplace",
      description: "Developed a full-stack e-commerce marketplace connecting farmers with customers, featuring custom dashboards for real-time tracking of sales and transactions.",
      tags: ["HTML", "CSS", "JavaScript", "Node.js", "MongoDB"],
      category: "E-commerce",
      categoryColor: "bg-green-500/20 text-green-400",
      accuracy: "Full Stack",
      githubUrl: "#",
      liveUrl: "#"
    },
    {
      title: "AGRIMART MOBILE",
      subtitle: "Android E-commerce App",
      description: "Developed an Android application for AgriMart marketplace using XML for UI design and Java for backend integration, featuring responsive design and seamless user experience.",
      tags: ["Android Studio", "XML", "Java", "API Integration"],
      category: "Mobile App",
      categoryColor: "bg-purple-500/20 text-purple-400",
      accuracy: "Native Android",
      githubUrl: "#",
      liveUrl: "#"
    },
    {
      title: "Nano-Mechanical Analysis",
      subtitle: "Material Science Research",
      description: "Conducting comprehensive research on vehicle gear materials utilizing nanoindentation test results analyzed through Python and Data Analysis techniques with ML models.",
      tags: ["Python", "Data Analysis", "Machine Learning", "Statistics"],
      category: "Research",
      categoryColor: "bg-blue-500/20 text-blue-400",
      accuracy: "Ongoing",
      githubUrl: "#",
      liveUrl: "#"
    }
  ];

  return (
    <section id="projects" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 text-primary">&lt;Projects/&gt;</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="project-card glass-effect p-6 rounded-lg transition-all duration-300">
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-bold text-primary">{project.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded ${project.categoryColor}`}>
                    {project.category}
                  </span>
                </div>
                <p className="text-sm text-slate-400 mb-4">{project.subtitle}</p>
              </div>
              
              <p className="text-slate-300 mb-4 text-sm leading-relaxed">
                {project.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tags.map((tag, tagIndex) => (
                  <span key={tagIndex} className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded">
                    {tag}
                  </span>
                ))}
              </div>
              
              <div className="flex justify-between items-center">
                <div className="text-sm">
                  <span className="text-primary font-semibold">{project.accuracy}</span>
                  <span className="text-slate-400 ml-1">
                    {project.accuracy === "97%" ? "Accuracy" : 
                     project.accuracy === "Full Stack" ? "MERN" : "2024-Current"}
                  </span>
                </div>
                <div className="space-x-2">
                  <button className="text-primary hover:text-primary/70 transition-colors">
                    <Github size={16} />
                  </button>
                  <button className="text-primary hover:text-primary/70 transition-colors">
                    <ExternalLink size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
