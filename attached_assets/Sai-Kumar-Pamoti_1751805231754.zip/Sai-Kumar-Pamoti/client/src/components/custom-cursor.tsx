export function CustomCursor() {
  // Return null to use default cursor
  return null;
}
