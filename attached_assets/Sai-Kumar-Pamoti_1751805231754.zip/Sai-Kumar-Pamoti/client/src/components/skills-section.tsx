import { Code, Shield, Wrench, Trophy, Medal, Rocket } from "lucide-react";
import { useEffect, useRef } from "react";

export function SkillsSection() {
  const skillsRef = useRef<HTMLDivElement>(null);

  const programmingSkills = {
    proficient: ["Java", "SQL", "HTML", "CSS"],
    experienced: ["Python", "JavaScript", "C", "C++"],
    familiar: ["R Programming"]
  };

  const cybersecuritySkills = [
    "Malware Analysis",
    "Intrusion Detection", 
    "Network Security",
    "Threat Analysis",
    "Security Frameworks"
  ];

  const libraries = [
    "Express.js", "Pandas", "Numpy", "Matplotlib", "nlkt", "Sklearn"
  ];

  const tools = [
    { name: "Git", icon: "🔧" },
    { name: "Burp Suite", icon: "🐛" },
    { name: "Wireshark", icon: "🌐" },
    { name: "Figma", icon: "🎨" },
    { name: "Cisco Packet Tracer", icon: "🌐" }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const skillBars = entry.target.querySelectorAll('.skill-bar');
            skillBars.forEach((bar) => {
              const element = bar as HTMLElement;
              const width = element.dataset.width;
              element.style.width = '0%';
              setTimeout(() => {
                element.style.width = width + '%';
              }, 300);
            });
          }
        });
      },
      { threshold: 0.5 }
    );

    if (skillsRef.current) {
      observer.observe(skillsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="skills" className="py-20">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 text-primary">&lt;Skills/&gt;</h2>
        
        <div ref={skillsRef} className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Programming Languages */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <Code className="mr-3" />
              Programming
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-primary mb-2">Proficient:</h4>
                <div className="flex flex-wrap gap-2">
                  {programmingSkills.proficient.map((skill, index) => (
                    <span key={index} className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-primary mb-2">Experienced:</h4>
                <div className="flex flex-wrap gap-2">
                  {programmingSkills.experienced.map((skill, index) => (
                    <span key={index} className="bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-primary mb-2">Familiar:</h4>
                <div className="flex flex-wrap gap-2">
                  {programmingSkills.familiar.map((skill, index) => (
                    <span key={index} className="bg-slate-500/20 text-slate-300 px-2 py-1 rounded text-xs">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Cybersecurity */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <Shield className="mr-3" />
              Cybersecurity
            </h3>
            <div className="space-y-3">
              {cybersecuritySkills.map((skill, index) => (
                <div key={index} className="flex items-center">
                  <span className="text-green-400 mr-3">✓</span>
                  <span className="text-sm">{skill}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Libraries/Frameworks */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <Code className="mr-3" />
              Libraries/Frameworks
            </h3>
            <div className="space-y-3">
              {libraries.map((library, index) => (
                <div key={index} className="flex items-center">
                  <span className="text-green-400 mr-3">✓</span>
                  <span className="text-sm">{library}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tools & Platforms */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <Wrench className="mr-3" />
              Tools/Platforms
            </h3>
            <div className="space-y-3">
              {tools.map((tool, index) => (
                <div key={index} className="flex items-center">
                  <span className="mr-3">{tool.icon}</span>
                  <span className="text-sm">{tool.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
