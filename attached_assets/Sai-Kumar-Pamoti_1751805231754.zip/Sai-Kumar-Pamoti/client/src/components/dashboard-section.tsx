import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Users, MessageCircle, Mail, Check, X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Analytics, Comment, Contact } from "@shared/schema";

export function DashboardSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: analytics } = useQuery<Analytics>({
    queryKey: ["/api/analytics"],
  });

  const { data: pendingComments = [] } = useQuery<Comment[]>({
    queryKey: ["/api/comments/pending"],
  });

  const { data: unreadContacts = [] } = useQuery<Contact[]>({
    queryKey: ["/api/contacts/unread"],
  });

  const approveCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("PATCH", `/api/comments/${commentId}/approve`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Comment approved",
        description: "The comment is now visible to visitors.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/comments/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
    },
  });

  const rejectCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("DELETE", `/api/comments/${commentId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Comment rejected",
        description: "The comment has been removed.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/comments/pending"] });
    },
  });

  const markContactReadMutation = useMutation({
    mutationFn: async (contactId: number) => {
      const response = await apiRequest("PATCH", `/api/contacts/${contactId}/read`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts/unread"] });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
  });

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  return (
    <section id="dashboard" className="py-20 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 text-primary">&lt;Dashboard/&gt;</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="glass-effect p-6 rounded-lg text-center">
            <Eye className="text-primary text-3xl mb-4 mx-auto" />
            <h3 className="text-2xl font-bold">{analytics?.totalViews || 0}</h3>
            <p className="text-slate-400">Total Views</p>
          </div>
          
          <div className="glass-effect p-6 rounded-lg text-center">
            <Users className="text-green-400 text-3xl mb-4 mx-auto" />
            <h3 className="text-2xl font-bold">{analytics?.uniqueVisitors || 0}</h3>
            <p className="text-slate-400">Unique Visitors</p>
          </div>
          
          <div className="glass-effect p-6 rounded-lg text-center">
            <MessageCircle className="text-blue-400 text-3xl mb-4 mx-auto" />
            <h3 className="text-2xl font-bold">{pendingComments.length}</h3>
            <p className="text-slate-400">Pending Comments</p>
          </div>
          
          <div className="glass-effect p-6 rounded-lg text-center">
            <Mail className="text-purple-400 text-3xl mb-4 mx-auto" />
            <h3 className="text-2xl font-bold">{unreadContacts.length}</h3>
            <p className="text-slate-400">Unread Messages</p>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Recent Comments */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <MessageCircle className="mr-3" />
              Pending Comments
            </h3>
            <div className="space-y-4">
              {pendingComments.length === 0 ? (
                <p className="text-slate-400 text-center">No pending comments</p>
              ) : (
                pendingComments.slice(0, 5).map((comment) => (
                  <div key={comment.id} className="border-b border-slate-700 pb-4">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-semibold text-sm">{comment.name}</span>
                      <span className="text-slate-400 text-xs">
                        {formatDate(comment.createdAt)}
                      </span>
                    </div>
                    <p className="text-slate-300 text-sm mb-2">
                      {comment.comment.length > 100 
                        ? comment.comment.substring(0, 100) + "..." 
                        : comment.comment}
                    </p>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-green-400 border-green-400 hover:bg-green-400/10"
                        onClick={() => approveCommentMutation.mutate(comment.id)}
                        disabled={approveCommentMutation.isPending}
                      >
                        <Check size={12} className="mr-1" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-400 border-red-400 hover:bg-red-400/10"
                        onClick={() => rejectCommentMutation.mutate(comment.id)}
                        disabled={rejectCommentMutation.isPending}
                      >
                        <X size={12} className="mr-1" />
                        Reject
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
          
          {/* Recent Contacts */}
          <div className="glass-effect p-6 rounded-lg">
            <h3 className="text-xl font-bold text-primary mb-6 flex items-center">
              <Mail className="mr-3" />
              Recent Messages
            </h3>
            <div className="space-y-4">
              {unreadContacts.length === 0 ? (
                <p className="text-slate-400 text-center">No unread messages</p>
              ) : (
                unreadContacts.slice(0, 5).map((contact) => (
                  <div key={contact.id} className="border-b border-slate-700 pb-4">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-semibold text-sm">{contact.email}</span>
                      <span className="text-slate-400 text-xs">
                        {formatDate(contact.createdAt)}
                      </span>
                    </div>
                    <p className="text-slate-300 text-sm mb-1">
                      Subject: {contact.subject || "No subject"}
                    </p>
                    <p className="text-slate-400 text-xs mb-2">
                      From: {contact.name}
                    </p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-primary border-primary hover:bg-primary/10"
                      onClick={() => markContactReadMutation.mutate(contact.id)}
                      disabled={markContactReadMutation.isPending}
                    >
                      <ExternalLink size={12} className="mr-1" />
                      Mark as Read
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
