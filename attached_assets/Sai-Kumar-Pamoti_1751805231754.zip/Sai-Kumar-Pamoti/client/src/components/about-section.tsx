import { GraduationCap, Award, MapPin } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 text-primary">&lt;About Me/&gt;</h2>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <p className="text-lg text-slate-300 leading-relaxed">
              Currently pursuing my second year of B.Tech at BML Munjal University, I am passionate about 
              developing my skills in Cyber Security and Full Stack Development. Eager to learn, explore, and 
              grow in the field, I am constantly working towards building a strong foundation for a career in cybersecurity.
            </p>
            
            <p className="text-lg text-slate-300 leading-relaxed">
              Motivated individual passionate in exploring emerging technologies, solving complex challenges, 
              and continuously enhancing technical expertise and communication skills to make meaningful contributions.
            </p>
            
            <div className="flex justify-center mt-8">
              <div className="glass-effect p-4 rounded-lg text-center">
                <h3 className="text-2xl font-bold text-primary">5+</h3>
                <p className="text-sm text-slate-400">Projects</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-primary mb-4 flex items-center">
                <GraduationCap className="mr-2" />
                Education
              </h3>
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold">BML Munjal University</h4>
                  <p className="text-slate-400">B.Tech Computer Science • Aug 2023 - Present</p>
                </div>
                <div>
                  <h4 className="font-semibold">Sri Chaitanya Junior College</h4>
                  <p className="text-slate-400">Higher Secondary • June 2023</p>
                  <p className="text-sm text-primary">97.1%</p>
                </div>
              </div>
            </div>
            
            <div className="glass-effect p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-primary mb-4 flex items-center">
                <Award className="mr-2" />
                Certifications
              </h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center">
                  <span className="text-green-400 mr-2">✓</span>
                  Google Cybersecurity Professional Certificate
                </li>
                <li className="flex items-center">
                  <span className="text-green-400 mr-2">✓</span>
                  Mastercard Cybersecurity Job Simulation
                </li>
                <li className="flex items-center">
                  <span className="text-green-400 mr-2">✓</span>
                  Cisco Networking Academy Certificate
                </li>
                <li className="flex items-center">
                  <span className="text-green-400 mr-2">✓</span>
                  Tata Cybersecurity Analyst Job Simulation
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
