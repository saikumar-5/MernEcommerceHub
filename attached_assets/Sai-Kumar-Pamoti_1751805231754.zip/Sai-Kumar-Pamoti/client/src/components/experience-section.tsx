export function ExperienceSection() {
  const experiences = [
    {
      title: "Full Stack Web Developer",
      company: "Innodatatics - GenAI | Data Science | BI",
      period: "June 2025 - Present",
      location: "Hyderabad, Telangana",
      description: "Working on advanced web development projects with focus on GenAI integration and data science applications.",
      isCurrentRole: true
    },
    {
      title: "Cyber Security Tool Developer",
      company: "Durbhasi Gurukulam",
      period: "April 2025 - Present",
      location: "Remote",
      description: "Building a live IPS tool using Fail2Ban and Rust programming language. Gaining hands-on experience in network security, intrusion detection, and static malware analysis.",
      isCurrentRole: true
    },
    {
      title: "Research Assistant",
      company: "BML Munjal University",
      period: "August 2024 - Present",
      location: "Gurugram, Haryana",
      description: "Conducting research on heterogeneous nano-mechanical behavior of vehicle gear materials using Python data analysis and machine learning techniques.",
      isCurrentRole: true
    },

  ];

  return (
    <section id="experience" className="py-20 bg-slate-800/50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-16 text-primary">&lt;Experience/&gt;</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-primary"></div>
            
            {/* Experience items */}
            <div className="space-y-12">
              {experiences.map((exp, index) => (
                <div key={index} className={`relative flex flex-col md:flex-row items-start md:items-center ${index % 2 === 0 ? '' : 'md:flex-row-reverse'}`}>
                  <div className="absolute left-6 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-background z-10"></div>
                  
                  <div className={`ml-16 md:ml-0 md:w-1/2 ${index % 2 === 0 ? 'md:pr-8 md:text-right' : 'md:pl-8'}`}>
                    <div className="glass-effect p-6 rounded-lg">
                      <h3 className="text-xl font-bold text-primary">{exp.title}</h3>
                      <p className="text-slate-300 font-semibold">{exp.company}</p>
                      <p className="text-slate-400 text-sm mb-3">{exp.period} • {exp.location}</p>
                      <p className="text-slate-300 text-sm">{exp.description}</p>
                      {exp.isCurrentRole && (
                        <span className="inline-block mt-2 px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                          Current
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
