import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Heart, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertCommentSchema, type Comment } from "@shared/schema";

const commentFormSchema = insertCommentSchema.extend({
  name: z.string().min(1, "Name is required"),
  comment: z.string().min(5, "Comment must be at least 5 characters"),
  profession: z.string().min(1, "Profession is required"),
});

type CommentFormData = z.infer<typeof commentFormSchema>;

export function CommentsSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isLiked, setIsLiked] = useState(false);
  const [showCommentForm, setShowCommentForm] = useState(false);

  const form = useForm<CommentFormData>({
    resolver: zodResolver(commentFormSchema),
    defaultValues: {
      name: "",
      email: "",
      comment: "",
      profession: "",
    },
  });

  const { data: comments = [], isLoading } = useQuery<Comment[]>({
    queryKey: ["/api/comments"],
  });

  const commentMutation = useMutation({
    mutationFn: async (data: CommentFormData) => {
      const response = await apiRequest("POST", "/api/comments", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Comment submitted successfully!",
        description: "Your comment will be reviewed and published soon.",
      });
      form.reset();
      setShowCommentForm(false);
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
    },
    onError: (error) => {
      toast({
        title: "Error submitting comment",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const likeMutation = useMutation({
    mutationFn: async (commentId: number) => {
      const response = await apiRequest("POST", `/api/comments/${commentId}/like`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
    },
  });

  const onSubmit = (data: CommentFormData) => {
    commentMutation.mutate(data);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-6">
        {/* Action Buttons */}
        <div className="flex justify-center space-x-8 mb-12">
          <button
            onClick={handleLike}
            className={`group flex flex-col items-center transition-all duration-300 ${
              isLiked ? 'text-red-500' : 'text-slate-400 hover:text-red-400'
            }`}
          >
            <div className={`p-4 rounded-full border-2 transition-all duration-300 ${
              isLiked 
                ? 'border-red-500 bg-red-500/10 scale-110' 
                : 'border-slate-400 hover:border-red-400 hover:bg-red-400/5'
            }`}>
              <Heart 
                className={`h-6 w-6 transition-all duration-300 ${
                  isLiked ? 'fill-current' : ''
                }`} 
              />
            </div>
            <span className="text-sm mt-2 font-medium">Like</span>
          </button>

          <button
            onClick={() => setShowCommentForm(true)}
            className="group flex flex-col items-center text-slate-400 hover:text-primary transition-all duration-300"
          >
            <div className="p-4 rounded-full border-2 border-slate-400 hover:border-primary hover:bg-primary/5 transition-all duration-300">
              <MessageCircle className="h-6 w-6" />
            </div>
            <span className="text-sm mt-2 font-medium">Comment</span>
          </button>
        </div>

        {/* Comment Dialog */}
        <Dialog open={showCommentForm} onOpenChange={setShowCommentForm}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-primary">Leave a Comment</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Input 
                  placeholder="Your Name" 
                  {...form.register("name")}
                  className="w-full"
                />
                {form.formState.errors.name && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.name.message}</p>
                )}
              </div>
              <div>
                <Input 
                  placeholder="Your Profession" 
                  {...form.register("profession")}
                  className="w-full"
                />
                {form.formState.errors.profession && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.profession.message}</p>
                )}
              </div>
              <div>
                <Input 
                  placeholder="Email (Optional)" 
                  type="email"
                  {...form.register("email")}
                  className="w-full"
                />
              </div>
              <div>
                <Textarea 
                  placeholder="Your comment..." 
                  className="min-h-[100px] w-full"
                  {...form.register("comment")}
                />
                {form.formState.errors.comment && (
                  <p className="text-red-400 text-sm mt-1">{form.formState.errors.comment.message}</p>
                )}
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowCommentForm(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={commentMutation.isPending}
                >
                  {commentMutation.isPending ? "Submitting..." : "Submit"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Comments Display */}
        {comments.length > 0 && (
          <div className="max-w-2xl mx-auto space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="glass-effect p-4 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-semibold text-primary text-sm">{comment.name}</h4>
                    <p className="text-slate-400 text-xs">{formatDate(comment.createdAt)}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => likeMutation.mutate(comment.id)}
                      className="flex items-center space-x-1 text-slate-400 hover:text-red-400 transition-colors"
                    >
                      <Heart className="h-3 w-3" />
                      <span className="text-xs">{comment.likes}</span>
                    </button>
                  </div>
                </div>
                <p className="text-slate-300 text-sm">{comment.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}