import { useEffect, useRef } from "react";

export function useCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const mouseX = useRef(0);
  const mouseY = useRef(0);
  const cursorX = useRef(0);
  const cursorY = useRef(0);

  useEffect(() => {
    let lastTrailTime = 0;
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.current = e.clientX;
      mouseY.current = e.clientY;
      
      // Create trail effect (throttled)
      const now = Date.now();
      if (now - lastTrailTime > 50) { // Limit trail to every 50ms
        const trail = document.createElement('div');
        trail.className = 'cursor-trail';
        trail.style.left = mouseX.current + 'px';
        trail.style.top = mouseY.current + 'px';
        document.body.appendChild(trail);
        
        setTimeout(() => {
          trail.remove();
        }, 500);
        
        lastTrailTime = now;
      }
    };

    const updateCursor = () => {
      cursorX.current += (mouseX.current - cursorX.current) * 0.1;
      cursorY.current += (mouseY.current - cursorY.current) * 0.1;
      
      if (cursorRef.current) {
        cursorRef.current.style.left = cursorX.current + 'px';
        cursorRef.current.style.top = cursorY.current + 'px';
      }
      
      requestAnimationFrame(updateCursor);
    };

    const handleMouseEnter = () => {
      if (cursorRef.current) {
        cursorRef.current.style.transform = 'scale(1.5)';
        cursorRef.current.style.background = 'rgba(6, 182, 212, 0.2)';
      }
    };

    const handleMouseLeave = () => {
      if (cursorRef.current) {
        cursorRef.current.style.transform = 'scale(1)';
        cursorRef.current.style.background = 'rgba(6, 182, 212, 0.1)';
      }
    };

    // Add hover effects for interactive elements
    const interactiveElements = document.querySelectorAll('button, a, input, textarea, select, [role="button"]');
    interactiveElements.forEach(element => {
      element.addEventListener('mouseenter', handleMouseEnter);
      element.addEventListener('mouseleave', handleMouseLeave);
    });

    document.addEventListener('mousemove', handleMouseMove);
    updateCursor();

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      interactiveElements.forEach(element => {
        element.removeEventListener('mouseenter', handleMouseEnter);
        element.removeEventListener('mouseleave', handleMouseLeave);
      });
    };
  }, []);

  return cursorRef;
}
