export const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

export function createIntersectionObserver(callback: IntersectionObserverCallback) {
  return new IntersectionObserver(callback, observerOptions);
}

export function animateOnScroll() {
  const observer = createIntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-slide-up');
      }
    });
  });

  document.querySelectorAll('section').forEach(section => {
    observer.observe(section);
  });

  return observer;
}

export function animateSkillBars() {
  const skillObserver = createIntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const target = entry.target as HTMLElement;
        const width = target.style.width;
        target.style.width = '0%';
        setTimeout(() => {
          target.style.width = width;
        }, 300);
      }
    });
  });

  document.querySelectorAll('.skill-bar').forEach(bar => {
    skillObserver.observe(bar);
  });

  return skillObserver;
}

export function smoothScrollToSection(href: string) {
  const target = document.querySelector(href);
  if (target) {
    target.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }
}
